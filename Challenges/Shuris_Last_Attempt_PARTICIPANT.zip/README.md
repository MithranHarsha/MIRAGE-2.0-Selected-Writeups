# Shuri's Last Attempt

Wakanda's final recovery protocol has been locked behind a damaged Mind Stone interface.

Shuri has one last attempt to recover the signal before the system becomes permanently inaccessible. The program does not behave like an ordinary authentication check, and the core logic is buried behind its own execution layer.

Recover the key, survive the defenses, and uncover the final signal.

**Category:** Reverse Engineering
**Difficulty:** Hard
**Points:** 300

### Files
- `challenge/shuris_last_attempt` — Linux x86-64 executable

### Objective
Reverse the program and recover the 18-character recovery key. The final signal is revealed only after the core accepts the correct sequence.

> Not every path through the core leads to the real answer.
