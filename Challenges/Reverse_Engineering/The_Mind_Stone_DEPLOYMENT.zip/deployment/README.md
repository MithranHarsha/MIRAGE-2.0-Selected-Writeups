# THE MIND STONE — Deployment

Port: 1711/tcp

Deploy from `challenge/`:

```bash
sudo docker build -t mind-stone-final:latest .
sudo docker rm -f mind-stone-final 2>/dev/null || true
sudo docker run -d   --name mind-stone-final   --restart unless-stopped   --memory=192m   --cpus=0.40   -p 1711:1711   mind-stone-final:latest
```

Verify:

```bash
sudo docker ps --filter "name=mind-stone-final"
sudo docker port mind-stone-final
nc 127.0.0.1 1711
```

Expected mapping:

`0.0.0.0:1711->1711/tcp`

The challenge uses a statically linked x86-64 binary, so it does not depend on the host/container glibc version.
