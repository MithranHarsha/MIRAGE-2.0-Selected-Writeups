# Scan Vision's Core

Vision's core has gone dark.

The diagnostic interface still responds, but the authentication
routine protecting the recovery channel is buried inside the damaged core.

Recover the diagnostic password and restore the core.

## Files

- `vision_core` — Linux x86-64 challenge binary

## Goal

Find the correct diagnostic password and obtain the flag.

The challenge is intended to be solved through static/dynamic
analysis of the supplied binary.
