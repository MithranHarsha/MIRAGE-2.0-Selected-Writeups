# Shuri's Last Attempt — VM Deployment

Remote service: TCP 1710

## Deploy

From this directory:

```bash
cd challenge
sudo docker build -t shuri-last-attempt:latest .
sudo docker rm -f shuri-last-attempt 2>/dev/null || true
sudo docker run -d   --name shuri-last-attempt   --restart unless-stopped   --memory=192m   --cpus=0.40   -p 1710:1710   shuri-last-attempt:latest
```

## Verify the container

```bash
sudo docker ps --filter "name=shuri-last-attempt"
sudo docker port shuri-last-attempt
```

Expected port mapping:

```text
0.0.0.0:1710->1710/tcp
```

## Test locally on the VM

```bash
nc 127.0.0.1 1710
```

You should see the Shuri's Last Attempt terminal interface.

## Test from another machine

```bash
nc <VM-PUBLIC-IP> 1710
```

If localhost works but the public connection does not, check the Azure NSG/firewall rule for TCP 1710. Do not modify or restart other challenge containers.

## Stop/remove only this challenge

```bash
sudo docker rm -f shuri-last-attempt
```
