# P5 Corvus Glaives Edge

## Objective
Execute a precise strike to override the defenses.

## Execution
This is a standalone offline challenge. Run the binary locally on your own machine.
```bash
chmod +x corvus_glaives_edge
./corvus_glaives_edge
```

## Provided Files
corvus_glaives_edge
