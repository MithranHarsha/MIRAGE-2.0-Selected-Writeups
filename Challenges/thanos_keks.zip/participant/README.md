# Corrupted by Thanos's Attack

The lab was breached and its firmware dump was recovered in a damaged
state. Several regions survived, but the corruption left misleading
traces throughout the image.

Some strings look like flags. **Do not trust a flag merely because
`strings` finds it.**

Reconstruct the surviving recovery data and determine which information
actually belongs to the recovery chain.

## Objective

Recover the genuine MIRAGE flag from the firmware dump.

## Suggested tools

Linux command-line tools and Python are sufficient:

- `file`
- `xxd` / `hexdump`
- `strings`
- `grep`
- `python3`
- `binwalk` (optional)

No network connection is required.
