# Corrupted by Thanos's Attack

The lab's firmware image was damaged during Thanos's attack. The
main system no longer trusts its primary image, but an emergency
recovery partition may still contain something important.

You have been given a raw firmware dump recovered from the damaged
system.

Analyze the dump, identify its internal sections, recover the damaged
recovery archive, and determine what Thanos failed to erase.

## Objective

Recover the flag hidden inside the firmware image.

## Suggested tools

Standard Linux tools such as:

- `file`
- `xxd` / `hexdump`
- `strings`
- `grep`
- `python3`
- `binwalk` (optional)

No network connection is required.
